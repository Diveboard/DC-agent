Drawing Test
############

If you need directions, please read the top of drawing.cpp file, and the test.bkl file with the comments about test_drawing and test_drawingplugin items.
