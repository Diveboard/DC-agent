This directory is expected to contain reference files and images produced by graphics/drawing.cpp test.
